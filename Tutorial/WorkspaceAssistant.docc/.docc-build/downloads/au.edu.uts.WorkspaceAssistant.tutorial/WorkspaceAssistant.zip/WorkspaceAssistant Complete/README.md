# Workspace Assistant

A task board with an **on-device AI agent** (Apple Foundation Models). Type what you want in plain
English and watch the agent change the board for you: tiles move, columns fill, the layout morphs.

Requirements: Xcode 26.1+, iOS 26. The real agent needs Apple Intelligence (a supported iPhone, or a
simulator on a Mac with Apple Intelligence turned on). Without it, a **simulated agent** takes over:
a keyword-based stand-in, clearly labelled in the chat, that handles short requests like the suggestions.

You can also work alongside the agent: **+** adds a task, **tap** a tile to complete or reopen it,
**press and hold** a tile to prioritise, complete or delete it.

---

## Step-by-step tutorial

`Tutorial/WorkspaceAssistant.docc` is an interactive DocC tutorial that builds this app from an empty
project: 6 tutorials, 38 steps, with quizzes. It lives outside the app target, so building the app never
touches it.

- **To view it:** double-click `Tutorial/Preview Tutorial.command`. Your browser opens the tutorial;
  keep the Terminal window open while you use it. Others on the same Wi-Fi can open it using your Mac's IP address instead of `localhost`.
- **To hand it out:** double-click `Tutorial/Export Tutorial.command`. It creates
  `Workspace Assistant Tutorial.doccarchive`, which participants double-click to open in Xcode.

| Chapter | Tutorial | Builds |
|---------|----------|--------|
| The Board | Modelling the Board | `TaskItem`, `Workspace` |
| The Board | Drawing the Board | `BoardView`, `ContentView`, the app |
| The Agent | Giving the Agent Tools | `Tools.swift` |
| The Agent | Talking to the Agent | `TaskAgent`, `AgentPanel`, the agent sheet |
| Working Together | Working Alongside the Agent | New-task form, tile menu, simulated agent |
| Working Together | Your First Tool | Lab 1: `DeprioritizeTaskTool` |

The last step of every file matches the code in this project exactly (the final tutorial is the Lab 1 solution).

## The whole app in one picture

```
 "Prioritise the memory leak and show my tasks as a board"
                     │
                     ▼
     TaskAgent ── session.respond(to:) ──► on-device model
                                               │  decides to call tools
                     ┌─────────────────────────┤
                     ▼                         ▼
          PrioritizeTaskTool            SwitchLayoutTool
                     │                         │
                     └──────────┬──────────────┘
                                ▼
     Workspace (the ONLY place state changes, for taps AND tools)
                                │  returns a truthful sentence to the model
                                ▼
                SwiftUI redraws the board, with animation
```

## Read the code in this order (10 files)

| # | File | One-line idea |
|---|------|---------------|
| 1 | `Model/TaskItem.swift` | The data. `@Generable` enums = the model can only pick valid values. |
| 2 | `Model/Workspace.swift` | Commands. UI taps and AI tools call the **same** methods; only `by: .user` / `by: .agent` differs. |
| 3 | `Agent/Tools.swift` | The 4 tools: name + description + `@Generable Arguments` + `call()`. |
| 4 | `Agent/TaskAgent.swift` | One `LanguageModelSession` with tools and instructions. The agentic loop is inside `respond(to:)`. |
| 5 | `Views/BoardView.swift` | Only reads `Workspace`, so every agent change animates in for free. |
| 6 | `Views/AgentPanel.swift` | Chat. Tool calls appear live as chips. |
| 7 | `Views/ContentView.swift` | Board + agent sheet (half height, so the board stays visible). |
| 8 | `Views/NewTaskSheet.swift` | The user's "add task" form: the same `addTask` command the tool calls. |
| 9 | `WorkspaceAssistantApp.swift` | Creates the workspace and the agent. |
| – | `Agent/SimulatedAgent.swift` | Backup for Macs/devices without Apple Intelligence. Not AI, no need to show it. |

## Demo script (the "wow" moment)

Open the agent sheet and tap the suggestions in order, or type:

1. *Add a high-priority task to review pull requests*
2. *Prioritise the memory leak and show my tasks as a board*  (two tools, one prompt)
3. *I finished the unit tests and the CI pipeline*  (tasks slide into Done)
4. *Now make the onboarding redesign important too*  (the model remembers the conversation)
5. *Mark the database migration as done*  (no such task: the agent says so instead of pretending)
6. Now **press and hold** a tile and delete it yourself, or add one with **+**. Point out that your tap
   and the agent's tool ran the same `Workspace` command, and only the agent's changes appear as chips.

**Reset Board** in the top-right menu restores the starting state between runs.

---

## Labs (Day 2)

### Lab 1 · Your first tool: `DeprioritizeTaskTool` (10:30)

1. In `Workspace.swift`, add the command next to `prioritize`, and the agent's way in next to `prioritizeTask`:

```swift
@discardableResult
func deprioritize(_ id: TaskItem.ID, by: ChangedBy) -> String {
    guard let index = index(of: id) else { return "That task no longer exists." }
    guard tasks[index].isHighPriority else { return "“\(tasks[index].title)” isn’t high priority. Nothing changed." }
    tasks[index].isHighPriority = false
    tasks[index].revision += 1
    return record("star.slash.fill", "Deprioritised “\(tasks[index].title)”", by: by)
}

func deprioritizeTask(_ query: String) -> String {
    guard let id = findTask(query) else { return problem(query) }
    return deprioritize(id, by: .agent)
}
```

2. In `Tools.swift`, add the tool:

```swift
struct DeprioritizeTaskTool: Tool {
    let name = "deprioritizeTask"
    let description = "Removes high priority from an existing task."
    let workspace: Workspace

    @Generable
    struct Arguments {
        @Guide(description: "The user's words for the task, e.g. 'memory leak'")
        var task: String
    }

    func call(arguments: Arguments) async throws -> String {
        await workspace.deprioritizeTask(arguments.task)
    }
}
```

3. Register it in `TaskAgent.makeSession(for:)`: add `DeprioritizeTaskTool(workspace: workspace),` to `tools`.
4. Bonus: add a "Deprioritise" button to the tile's press-and-hold menu in `BoardView.swift`, calling `deprioritize(task.id, by: .user)`.
5. Try: *"The memory leak can wait."* Then try a vague description and see whether the model still picks your tool.
   Discuss: the **description** is the API contract the model reads.

### Lab 2 · Streaming the reply (11:30)

In `TaskAgent.swift`:

```swift
private(set) var streamingText = ""          // 1. new property

// 2. in send(_:), replace the `let response = try await session.respond(to: prompt)` line and the one after it:
streamingText = ""
for try await snapshot in session.streamResponse(to: prompt) {
    streamingText = snapshot.content
}
messages.append(Message(role: .agent, text: streamingText, actions: liveActions))
```

In `AgentPanel.swift`, pass it to `WorkingRow` and show it under the chips:
`if !text.isEmpty { Label(text, systemImage: "sparkles") }`.

### Lab 3 · Sessions (13:30)

- Tap **New Chat**, then say *"undo that"*: the model has forgotten. Sessions are memory.
- Move `makeSession` into `send(_:)` so every prompt gets a new session. What breaks?
- Dynamic instructions: add a user profile to the instructions, e.g.
  *"The user is Rina, an iOS lead. Treat anything about release or App Store as high priority."*
  Then ask: *"Add a task to submit the build to the App Store."*

### Lab 4 · Build a new tool (14:30), pick one

| Tool | What it teaches |
|------|-----------------|
| `ListTasksTool` (returns open tasks, changes nothing) | Read-only tools let the model look before it acts |
| `RenameTaskTool` | Two arguments the model has to fill |
| `ClearDoneTasksTool` | One call, many changes |
| `SetCategoryTool` (argument: `TaskCategory`) | Reusing a `@Generable` enum |
| `SetAccentColorTool` | The AI changes the app's look, not only its data (Day 3 preview) |

Every tool follows the same three steps as Lab 1: command in `Workspace`, tool in `Tools.swift`, register in `makeSession`.
`delete(_:by:)` already exists for the user's menu, so a `DeleteTaskTool` only needs the "agent's way in" plus the tool.

New tools need the real model: the simulated agent only knows the four built-in ones.
